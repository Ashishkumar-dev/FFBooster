package com.ashish.ffbooster

import android.content.Context
import android.content.pm.ApplicationInfo

object Boost {

    fun findGame(ctx: Context): String? =
        ctx.packageManager.getInstalledApplications(0)
            .firstOrNull { it.packageName.startsWith("com.garena.game.ff") }
            ?.packageName

    fun killList(ctx: Context): List<String> {
        val keep = Prefs.protectedApps(ctx)
        return ctx.packageManager.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .map { it.packageName }
            .filter {
                it != ctx.packageName &&
                    !it.contains("garena") &&
                    it != "moe.shizuku.privileged.api" &&
                    it !in keep
            }
    }

    private fun step(label: String, cmd: String, log: (String) -> Unit) {
        val (code, out) = ShizukuShell.exec(cmd)
        val mark = if (code == 0) "✔" else "✗"
        val extra = if (out.isNotBlank()) " - ${out.take(100)}" else ""
        log("$mark $label$extra")
    }

    /** Gaming ke liye sab tweaks ON (Shizuku chahiye). */
    fun enable(ctx: Context, game: String?, log: (String) -> Unit) {
        val killCmd = killList(ctx).joinToString("; ") { "am force-stop $it" }
        if (killCmd.isNotEmpty()) step("Background apps force-stop", killCmd, log)
        step("Cached processes saaf", "am kill-all", log)
        step("Battery saver OFF", "settings put global low_power 0", log)
        step(
            "Animations 0.5x",
            "settings put global window_animation_scale 0.5; " +
                "settings put global transition_animation_scale 0.5; " +
                "settings put global animator_duration_scale 0.5",
            log
        )
        step("DND (priority only)", "cmd notification set_dnd priority", log)
        if (Prefs.headsUp(ctx)) {
            step("Heads-up popups band", "settings put global heads_up_notifications_enabled 0", log)
        }
        if (Prefs.wifi(ctx)) {
            step("Wi-Fi low latency ON", "cmd wifi force-low-latency-mode enabled", log)
        }
        val hz = Prefs.refresh(ctx)
        if (hz > 0) {
            step(
                "Refresh rate ${hz}Hz",
                "settings put system min_refresh_rate ${hz}.0; settings put system peak_refresh_rate ${hz}.0",
                log
            )
        }
        if (game != null) {
            step(
                "Game mode: Performance",
                "cmd game set --mode performance --user 0 $game || cmd game mode performance $game",
                log
            )
            step("Game ko battery restriction se bachao", "cmd deviceidle whitelist +$game", log)
        }
    }

    /** Sab kuch normal par wapas. */
    fun disable(ctx: Context, game: String?, log: (String) -> Unit) {
        step(
            "Animations 1x",
            "settings put global window_animation_scale 1.0; " +
                "settings put global transition_animation_scale 1.0; " +
                "settings put global animator_duration_scale 1.0",
            log
        )
        step("DND OFF", "cmd notification set_dnd off", log)
        if (Prefs.headsUp(ctx)) {
            step("Heads-up popups ON", "settings put global heads_up_notifications_enabled 1", log)
        }
        if (Prefs.wifi(ctx)) {
            step("Wi-Fi low latency OFF", "cmd wifi force-low-latency-mode disabled", log)
        }
        if (Prefs.refresh(ctx) > 0) {
            step(
                "Refresh rate default",
                "settings delete system min_refresh_rate; settings delete system peak_refresh_rate",
                log
            )
        }
        if (game != null) {
            step(
                "Game mode: Standard",
                "cmd game set --mode standard --user 0 $game || cmd game mode standard $game",
                log
            )
            step("Battery whitelist hatao", "cmd deviceidle whitelist -$game", log)
        }
    }

    fun clearCaches(log: (String) -> Unit) {
        step("System-wide cache saaf", "pm trim-caches 128G", log)
    }

    fun compileGame(game: String, log: (String) -> Unit) {
        step("Game compile (speed-profile)", "cmd package compile -m speed-profile -f $game", log)
    }
}
