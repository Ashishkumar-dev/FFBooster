package com.ashish.ffbooster

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuShell {

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun requestPermission(code: Int) {
        try {
            Shizuku.requestPermission(code)
        } catch (e: Throwable) {
            // Shizuku chalu nahi hai
        }
    }

    fun isReady(): Boolean = isRunning() && hasPermission()

    /** Shell (uid 2000) ke through command chalata hai. Returns (exitCode, output). */
    fun exec(cmd: String): Pair<Int, String> {
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            val code = process.waitFor()
            code to (out + err).trim()
        } catch (e: Throwable) {
            -1 to (e.message ?: "error")
        }
    }
}
