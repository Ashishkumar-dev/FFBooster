package com.ashish.ffbooster

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class GameService : Service() {

    companion object {
        @Volatile var isRunning = false
        @Volatile var hudShown = false
    }

    private var worker: Thread? = null
    private var wm: WindowManager? = null
    private var hud: TextView? = null
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var loopOn = false
    @Volatile private var pingMs = -1L
    private var inGame = false
    private var missCount = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (!loopOn) {
            loopOn = true
            isRunning = true
            setupHud()
            worker = thread { loop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        loopOn = false
        isRunning = false
        worker?.interrupt()
        removeHud()
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("ffb", "FF Booster", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "ffb")
            .setContentTitle("FF Booster active")
            .setContentText("Auto game mode / HUD chal raha hai (band karne ke liye app kholo)")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- HUD ----------

    private fun setupHud() {
        if (!Prefs.hud(this) || !Settings.canDrawOverlays(this)) return
        try {
            val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val tv = TextView(this).apply {
                textSize = 12f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#99000000"))
                setPadding(16, 8, 16, 8)
                text = "FF Booster HUD"
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 16
                y = 8
            }
            manager.addView(tv, lp)
            wm = manager
            hud = tv
            hudShown = true
        } catch (e: Exception) {
            hudShown = false
        }
    }

    private fun removeHud() {
        try {
            hud?.let { wm?.removeView(it) }
        } catch (e: Exception) {
            // ignore
        }
        hud = null
        hudShown = false
    }

    private fun updateHud(temp: Double, freeMb: Long, level: Int) {
        val t = hud ?: return
        val ping = if (pingMs >= 0) "${pingMs}ms" else "--"
        val txt = "RAM ${freeMb}MB | ${temp}°C | $ping | $level%"
        ui.post {
            t.text = txt
            t.setTextColor(if (temp >= 43) Color.parseColor("#FC8181") else Color.WHITE)
        }
    }

    // ---------- Loop ----------

    private fun measurePing() {
        pingMs = try {
            val s = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
            (System.nanoTime() - s) / 1_000_000
        } catch (e: Exception) {
            -1L
        }
    }

    private fun loop() {
        val game = Boost.findGame(this)
        var tick = 0
        while (loopOn) {
            try {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
                val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0

                if (tick % 2 == 0) measurePing()

                if (Prefs.auto(this) && game != null && ShizukuShell.isReady()) {
                    val (_, out) = ShizukuShell.exec("dumpsys window | grep mCurrentFocus")
                    val nowIn = out.contains(game)
                    if (nowIn) {
                        missCount = 0
                        if (!inGame) {
                            inGame = true
                            Boost.enable(this, game) { }
                        }
                    } else if (inGame) {
                        missCount++
                        if (missCount >= 2) {
                            inGame = false
                            missCount = 0
                            Boost.disable(this, game) { }
                        }
                    }
                }

                updateHud(temp, mi.availMem / (1024 * 1024), level)
                tick++
                Thread.sleep(3000)
            } catch (e: InterruptedException) {
                break
            } catch (e: Throwable) {
                try { Thread.sleep(3000) } catch (ie: InterruptedException) { break }
            }
        }
    }
}
