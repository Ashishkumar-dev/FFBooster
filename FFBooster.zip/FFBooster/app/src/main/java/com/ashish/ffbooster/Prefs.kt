package com.ashish.ffbooster

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("ffb", Context.MODE_PRIVATE)

    fun protectedApps(c: Context): Set<String> =
        HashSet(sp(c).getStringSet("protected", emptySet()) ?: emptySet())

    fun setProtected(c: Context, s: Set<String>) {
        sp(c).edit().putStringSet("protected", s).apply()
    }

    fun auto(c: Context) = sp(c).getBoolean("auto", false)
    fun setAuto(c: Context, v: Boolean) { sp(c).edit().putBoolean("auto", v).apply() }

    fun hud(c: Context) = sp(c).getBoolean("hud", false)
    fun setHud(c: Context, v: Boolean) { sp(c).edit().putBoolean("hud", v).apply() }

    fun headsUp(c: Context) = sp(c).getBoolean("headsup", true)
    fun setHeadsUp(c: Context, v: Boolean) { sp(c).edit().putBoolean("headsup", v).apply() }

    fun wifi(c: Context) = sp(c).getBoolean("wifi", true)
    fun setWifi(c: Context, v: Boolean) { sp(c).edit().putBoolean("wifi", v).apply() }

    /** 0 = auto (touch nahi karna), warna 60/90/120 */
    fun refresh(c: Context) = sp(c).getInt("refresh", 0)
    fun setRefresh(c: Context, v: Int) { sp(c).edit().putInt("refresh", v).apply() }
}
