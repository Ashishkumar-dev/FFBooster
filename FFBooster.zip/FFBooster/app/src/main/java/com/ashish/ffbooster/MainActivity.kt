package com.ashish.ffbooster

import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var statsView: TextView
    private lateinit var pingView: TextView
    private lateinit var shizukuView: TextView
    private lateinit var logView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val reqCode = 1001

    private val permListener =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { updateShizukuStatus() } }
    private val binderListener =
        Shizuku.OnBinderReceivedListener { runOnUiThread { updateShizukuStatus() } }
    private val deadListener =
        Shizuku.OnBinderDeadListener { runOnUiThread { updateShizukuStatus() } }

    private val refresh = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
            setBackgroundColor(Color.parseColor("#101418"))
        }

        val title = TextView(this).apply {
            text = "FF Booster"
            textSize = 28f
            setTextColor(Color.parseColor("#FF6B00"))
            gravity = Gravity.CENTER
        }
        shizukuView = TextView(this).apply {
            textSize = 15f
            setPadding(0, 30, 0, 10)
        }
        statsView = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 20, 0, 20)
        }
        pingView = TextView(this).apply {
            text = "Ping: abhi check nahi kiya"
            textSize = 16f
            setTextColor(Color.parseColor("#9AE6B4"))
            setPadding(0, 0, 0, 30)
        }
        logView = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#B0BEC5"))
            setPadding(0, 30, 0, 0)
        }

        val shizukuBtn = Button(this).apply {
            text = "SHIZUKU CONNECT / PERMISSION"
            setOnClickListener { connectShizuku() }
        }
        val boostBtn = Button(this).apply {
            text = "BOOST + LAUNCH FREE FIRE"
            setOnClickListener { boostAndLaunch() }
        }
        val deepBtn = Button(this).apply {
            text = "DEEP OPTIMIZE GAME (Shizuku, 1-2 min)"
            setOnClickListener { deepOptimize() }
        }
        val restoreBtn = Button(this).apply {
            text = "RESTORE SETTINGS"
            setOnClickListener { restoreSettings() }
        }
        val pingBtn = Button(this).apply {
            text = "PING CHECK"
            setOnClickListener { checkPing() }
        }
        val dndBtn = Button(this).apply {
            text = "DND PERMISSION (bina Shizuku ke)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }
        val tips = TextView(this).apply {
            text = """
                Extra tips (Samsung A52s 5G):
                • Settings > Battery > Power saving OFF
                • Display > Motion smoothness > Adaptive/High
                • Game Launcher > Game Booster ON, Performance priority
                • Wi-Fi 5GHz ya 5G data, VPN/downloads band
                • Phone garam ho to cover hatao, charging band karke khelo
                • Free Fire: Graphics Smooth, FPS High/Max
            """.trimIndent()
            textSize = 14f
            setTextColor(Color.parseColor("#B0BEC5"))
            setPadding(0, 40, 0, 0)
        }

        root.addView(title)
        root.addView(shizukuView)
        root.addView(statsView)
        root.addView(pingView)
        root.addView(shizukuBtn)
        root.addView(boostBtn)
        root.addView(deepBtn)
        root.addView(restoreBtn)
        root.addView(pingBtn)
        root.addView(dndBtn)
        root.addView(logView)
        root.addView(tips)

        setContentView(ScrollView(this).apply { addView(root) })

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
        updateShizukuStatus()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
    }

    override fun onResume() {
        super.onResume()
        updateShizukuStatus()
        handler.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refresh)
    }

    // ---------- Status ----------

    private fun updateShizukuStatus() {
        when {
            !ShizukuShell.isRunning() -> {
                shizukuView.text = "Shizuku: chalu nahi hai (Shizuku app kholke start karo)"
                shizukuView.setTextColor(Color.parseColor("#FC8181"))
            }
            !ShizukuShell.hasPermission() -> {
                shizukuView.text = "Shizuku: chal raha hai, permission chahiye"
                shizukuView.setTextColor(Color.parseColor("#F6E05E"))
            }
            else -> {
                shizukuView.text = "Shizuku: connected ✔"
                shizukuView.setTextColor(Color.parseColor("#68D391"))
            }
        }
    }

    private fun updateStats() {
        val mi = memInfo()
        val freeMb = mi.availMem / (1024 * 1024)
        val totalMb = mi.totalMem / (1024 * 1024)

        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0

        val warn = if (temp >= 42) "  ⚠ Garam hai, throttling ho sakti hai" else ""
        statsView.text = "RAM free: $freeMb MB / $totalMb MB\n" +
            "Battery: $level%\nTemp: $temp °C$warn"
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    private fun log(msg: String) {
        runOnUiThread { logView.append(msg + "\n") }
    }

    // ---------- Shizuku ----------

    private fun connectShizuku() {
        when {
            !ShizukuShell.isRunning() -> {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i)
                else Toast.makeText(this, "Pehle Shizuku app install karo", Toast.LENGTH_LONG).show()
            }
            !ShizukuShell.hasPermission() -> ShizukuShell.requestPermission(reqCode)
            else -> Toast.makeText(this, "Shizuku already connected", Toast.LENGTH_SHORT).show()
        }
    }

    private fun runStep(label: String, cmd: String) {
        val (code, out) = ShizukuShell.exec(cmd)
        val mark = if (code == 0) "✔" else "✗"
        val extra = if (out.isNotBlank()) " - ${out.take(100)}" else ""
        log("$mark $label$extra")
    }

    private fun thirdPartyKillList(): List<String> {
        return packageManager.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .map { it.packageName }
            .filter {
                it != packageName &&
                    !it.contains("garena") &&
                    it != "moe.shizuku.privileged.api"
            }
    }

    private fun shizukuBoost(onDone: () -> Unit) {
        val game = findGamePackage()
        logView.text = ""
        thread {
            val before = memInfo().availMem

            val killCmd = thirdPartyKillList().joinToString("; ") { "am force-stop $it" }
            if (killCmd.isNotEmpty()) runStep("Background apps force-stop", killCmd)
            runStep("Cached processes saaf", "am kill-all")
            runStep("Battery saver OFF", "settings put global low_power 0")
            runStep(
                "Animations halka (0.5x)",
                "settings put global window_animation_scale 0.5; " +
                    "settings put global transition_animation_scale 0.5; " +
                    "settings put global animator_duration_scale 0.5"
            )
            runStep("DND (priority only)", "cmd notification set_dnd priority")
            if (game != null) {
                runStep(
                    "Game mode: Performance",
                    "cmd game set --mode performance --user 0 $game || cmd game mode performance $game"
                )
            }

            Thread.sleep(700)
            val freedMb = (memInfo().availMem - before) / (1024 * 1024)
            log("RAM freed: ${maxOf(freedMb, 0)} MB")
            runOnUiThread(onDone)
        }
    }

    private fun deepOptimize() {
        if (!ShizukuShell.isReady()) {
            Toast.makeText(this, "Pehle Shizuku connect karo", Toast.LENGTH_LONG).show()
            return
        }
        val game = findGamePackage()
        if (game == null) {
            Toast.makeText(this, "Free Fire India installed nahi mila", Toast.LENGTH_LONG).show()
            return
        }
        logView.text = "Compile chal raha hai, app band mat karo...\n"
        thread {
            runStep("Game compile (speed-profile)", "cmd package compile -m speed-profile -f $game")
            log("Done.")
        }
    }

    private fun restoreSettings() {
        if (!ShizukuShell.isReady()) {
            Toast.makeText(this, "Pehle Shizuku connect karo", Toast.LENGTH_LONG).show()
            return
        }
        val game = findGamePackage()
        logView.text = ""
        thread {
            runStep(
                "Animations normal (1x)",
                "settings put global window_animation_scale 1.0; " +
                    "settings put global transition_animation_scale 1.0; " +
                    "settings put global animator_duration_scale 1.0"
            )
            runStep("DND OFF", "cmd notification set_dnd off")
            if (game != null) {
                runStep(
                    "Game mode: Standard",
                    "cmd game set --mode standard --user 0 $game || cmd game mode standard $game"
                )
            }
        }
    }

    // ---------- Boost (with / without Shizuku) ----------

    private fun boostAndLaunch() {
        if (ShizukuShell.isReady()) {
            shizukuBoost { launchFreeFire() }
            return
        }
        basicBoost()
    }

    private fun basicBoost() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = memInfo().availMem

        for (pkg in thirdPartyKillList()) {
            am.killBackgroundProcesses(pkg)
        }

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } else {
            Toast.makeText(this, "Shizuku nahi hai. Basic boost chal raha hai", Toast.LENGTH_LONG).show()
        }

        handler.postDelayed({
            val freedMb = (memInfo().availMem - before) / (1024 * 1024)
            Toast.makeText(this, "Boost done. Freed: ${maxOf(freedMb, 0)} MB", Toast.LENGTH_SHORT).show()
            launchFreeFire()
        }, 800)
    }

    private fun findGamePackage(): String? {
        return packageManager.getInstalledApplications(0)
            .firstOrNull { it.packageName.startsWith("com.garena.game.ff") }
            ?.packageName
    }

    private fun launchFreeFire() {
        val pkg = findGamePackage()
        val intent = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "Free Fire India installed nahi mila", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Ping ----------

    private fun checkPing() {
        pingView.text = "Ping check ho raha hai..."
        thread {
            val results = mutableListOf<Long>()
            repeat(4) {
                try {
                    val start = System.nanoTime()
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 2000) }
                    results.add((System.nanoTime() - start) / 1_000_000)
                } catch (e: Exception) {
                    // timeout ya network issue
                }
            }
            val msg = if (results.isEmpty()) {
                "Ping: network problem / timeout"
            } else {
                val avg = results.average().toInt()
                val quality = when {
                    avg < 50 -> "Mast"
                    avg < 100 -> "Theek"
                    else -> "Slow, Wi-Fi/data badlo"
                }
                "Ping: $avg ms ($quality)"
            }
            runOnUiThread { pingView.text = msg }
        }
    }
}
