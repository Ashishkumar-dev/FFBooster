package com.ashish.ffbooster

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var statsView: TextView
    private lateinit var pingView: TextView
    private lateinit var shizukuView: TextView
    private lateinit var logView: TextView
    private lateinit var refreshBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private val reqCode = 1001

    private val permListener =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { updateShizukuStatus() } }
    private val binderListener =
        Shizuku.OnBinderReceivedListener { runOnUiThread { updateShizukuStatus() } }
    private val deadListener =
        Shizuku.OnBinderDeadListener { runOnUiThread { updateShizukuStatus() } }

    private val refresh = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 2000)
        }
    }

    // ---------- UI helpers ----------

    private fun btn(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch =
        Switch(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isChecked = checked
            setPadding(0, 16, 0, 16)
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }

    private fun header(label: String): TextView =
        TextView(this).apply {
            text = label
            textSize = 17f
            setTextColor(Color.parseColor("#FF6B00"))
            setPadding(0, 40, 0, 8)
        }

    // ---------- Lifecycle ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
            setBackgroundColor(Color.parseColor("#101418"))
        }

        val title = TextView(this).apply {
            text = "FF Booster Pro"
            textSize = 28f
            setTextColor(Color.parseColor("#FF6B00"))
            gravity = Gravity.CENTER
        }
        shizukuView = TextView(this).apply {
            textSize = 15f
            setPadding(0, 30, 0, 10)
        }
        statsView = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 20, 0, 10)
        }
        pingView = TextView(this).apply {
            text = "Ping: abhi check nahi kiya"
            textSize = 16f
            setTextColor(Color.parseColor("#9AE6B4"))
            setPadding(0, 0, 0, 10)
        }
        logView = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#B0BEC5"))
            setPadding(0, 30, 0, 0)
        }
        refreshBtn = btn("") { cycleRefresh() }
        updateRefreshText()

        root.addView(title)
        root.addView(shizukuView)
        root.addView(statsView)
        root.addView(pingView)

        root.addView(header("Quick Actions"))
        root.addView(btn("BOOST + LAUNCH FREE FIRE") { boostAndLaunch() })
        root.addView(btn("RESTORE ALL SETTINGS") { restoreAll() })
        root.addView(btn("DEEP OPTIMIZE GAME (1-2 min)") { deepOptimize() })
        root.addView(btn("CLEAR ALL CACHE") { clearCaches() })
        root.addView(btn("PING CHECK") { checkPing() })

        root.addView(header("Auto Mode + HUD"))
        root.addView(sw("Auto Game Mode (game khulte hi boost)", Prefs.auto(this)) { v ->
            Prefs.setAuto(this, v)
            if (v && !ShizukuShell.isReady()) {
                Toast.makeText(this, "Auto mode ke liye Shizuku connect karo", Toast.LENGTH_LONG).show()
            }
            restartService()
        })
        root.addView(sw("Floating HUD (RAM | Temp | Ping | Battery)", Prefs.hud(this)) { v ->
            Prefs.setHud(this, v)
            if (v && !Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
            restartService()
        })

        root.addView(header("Tweaks"))
        root.addView(sw("Game ke time popups (heads-up) band", Prefs.headsUp(this)) { v ->
            Prefs.setHeadsUp(this, v)
        })
        root.addView(sw("Wi-Fi low latency mode", Prefs.wifi(this)) { v ->
            Prefs.setWifi(this, v)
        })
        root.addView(refreshBtn)
        root.addView(btn("PROTECTED APPS (inhe band mat karo)") { pickProtected() })

        root.addView(header("Setup"))
        root.addView(btn("SHIZUKU CONNECT / PERMISSION") { connectShizuku() })
        root.addView(btn("DND PERMISSION (bina Shizuku ke)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })

        root.addView(logView)

        val tips = TextView(this).apply {
            text = """
                Extra tips (Samsung A52s 5G):
                • Settings > Battery > Power saving OFF
                • Display > Motion smoothness > Adaptive/High
                • Game Launcher > Game Booster ON, Performance priority
                • Wi-Fi 5GHz ya 5G data, VPN/downloads band
                • Phone garam ho to cover hatao, charging band karke khelo
                • Free Fire: Graphics Smooth, FPS High/Max
            """.trimIndent()
            textSize = 14f
            setTextColor(Color.parseColor("#B0BEC5"))
            setPadding(0, 40, 0, 0)
        }
        root.addView(tips)

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
        }

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
        updateShizukuStatus()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
    }

    override fun onResume() {
        super.onResume()
        updateShizukuStatus()
        handler.post(refresh)
        if (needService()) {
            val hudMissing = Prefs.hud(this) &&
                Settings.canDrawOverlays(this) && !GameService.hudShown
            if (!GameService.isRunning || hudMissing) restartService()
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refresh)
    }

    // ---------- Service ----------

    private fun needService() = Prefs.auto(this) || Prefs.hud(this)

    private fun restartService() {
        val i = Intent(this, GameService::class.java)
        stopService(i)
        if (needService()) startForegroundService(i)
    }

    // ---------- Status ----------

    private fun updateShizukuStatus() {
        when {
            !ShizukuShell.isRunning() -> {
                shizukuView.text = "Shizuku: chalu nahi hai (Shizuku app kholke start karo)"
                shizukuView.setTextColor(Color.parseColor("#FC8181"))
            }
            !ShizukuShell.hasPermission() -> {
                shizukuView.text = "Shizuku: chal raha hai, permission chahiye"
                shizukuView.setTextColor(Color.parseColor("#F6E05E"))
            }
            else -> {
                shizukuView.text = "Shizuku: connected ✔"
                shizukuView.setTextColor(Color.parseColor("#68D391"))
            }
        }
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    private fun updateStats() {
        val mi = memInfo()
        val freeMb = mi.availMem / (1024 * 1024)
        val totalMb = mi.totalMem / (1024 * 1024)

        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0

        val warn = if (temp >= 42) "  ⚠ Garam hai, throttling ho sakti hai" else ""
        statsView.text = "RAM free: $freeMb MB / $totalMb MB\n" +
            "Battery: $level%\nTemp: $temp °C$warn"
    }

    private fun log(msg: String) {
        runOnUiThread { logView.append(msg + "\n") }
    }

    private fun requireShizuku(): Boolean {
        if (!ShizukuShell.isReady()) {
            Toast.makeText(this, "Pehle Shizuku connect karo", Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }

    // ---------- Shizuku ----------

    private fun connectShizuku() {
        when {
            !ShizukuShell.isRunning() -> {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i)
                else Toast.makeText(this, "Pehle Shizuku app install karo", Toast.LENGTH_LONG).show()
            }
            !ShizukuShell.hasPermission() -> ShizukuShell.requestPermission(reqCode)
            else -> Toast.makeText(this, "Shizuku already connected", Toast.LENGTH_SHORT).show()
        }
    }

    private fun boostAndLaunch() {
        if (!ShizukuShell.isReady()) {
            basicBoost()
            return
        }
        logView.text = ""
        val game = Boost.findGame(this)
        thread {
            val before = memInfo().availMem
            Boost.enable(this, game) { log(it) }
            Thread.sleep(700)
            val freedMb = (memInfo().availMem - before) / (1024 * 1024)
            log("RAM freed: ${maxOf(freedMb, 0)} MB")
            runOnUiThread { launchFreeFire() }
        }
    }

    private fun restoreAll() {
        if (!requireShizuku()) return
        logView.text = ""
        val game = Boost.findGame(this)
        thread { Boost.disable(this, game) { log(it) } }
    }

    private fun deepOptimize() {
        if (!requireShizuku()) return
        val game = Boost.findGame(this)
        if (game == null) {
            Toast.makeText(this, "Free Fire India installed nahi mila", Toast.LENGTH_LONG).show()
            return
        }
        logView.text = "Compile chal raha hai, app band mat karo...\n"
        thread {
            Boost.compileGame(game) { log(it) }
            log("Done.")
        }
    }

    private fun clearCaches() {
        if (!requireShizuku()) return
        logView.text = "Cache saaf ho raha hai...\n"
        thread {
            Boost.clearCaches { log(it) }
            log("Done.")
        }
    }

    // ---------- Tweaks ----------

    private fun cycleRefresh() {
        val next = when (Prefs.refresh(this)) {
            0 -> 60
            60 -> 90
            90 -> 120
            else -> 0
        }
        Prefs.setRefresh(this, next)
        updateRefreshText()
    }

    private fun updateRefreshText() {
        val v = Prefs.refresh(this)
        refreshBtn.text = if (v == 0) "REFRESH RATE: Auto (touch nahi)" else "REFRESH RATE LOCK: ${v}Hz"
    }

    private fun pickProtected() {
        val apps = packageManager.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != packageName }
        val names = apps.map { packageManager.getApplicationLabel(it).toString() }
        val pkgs = apps.map { it.packageName }
        val saved = Prefs.protectedApps(this)
        val checked = BooleanArray(pkgs.size) { saved.contains(pkgs[it]) }

        AlertDialog.Builder(this)
            .setTitle("Ye apps band mat karo")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                val keep = pkgs.filterIndexed { i, _ -> checked[i] }.toSet()
                Prefs.setProtected(this, keep)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Basic boost (Shizuku ke bina) ----------

    private fun basicBoost() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = memInfo().availMem

        for (pkg in Boost.killList(this)) {
            am.killBackgroundProcesses(pkg)
        }

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } else {
            Toast.makeText(this, "Shizuku nahi hai. Basic boost chal raha hai", Toast.LENGTH_LONG).show()
        }

        handler.postDelayed({
            val freedMb = (memInfo().availMem - before) / (1024 * 1024)
            Toast.makeText(this, "Boost done. Freed: ${maxOf(freedMb, 0)} MB", Toast.LENGTH_SHORT).show()
            launchFreeFire()
        }, 800)
    }

    private fun launchFreeFire() {
        val pkg = Boost.findGame(this)
        val intent = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "Free Fire India installed nahi mila", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Ping ----------

    private fun checkPing() {
        pingView.text = "Ping check ho raha hai..."
        thread {
            val results = mutableListOf<Long>()
            repeat(4) {
                try {
                    val start = System.nanoTime()
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 2000) }
                    results.add((System.nanoTime() - start) / 1_000_000)
                } catch (e: Exception) {
                    // timeout ya network issue
                }
            }
            val msg = if (results.isEmpty()) {
                "Ping: network problem / timeout"
            } else {
                val avg = results.average().toInt()
                val quality = when {
                    avg < 50 -> "Mast"
                    avg < 100 -> "Theek"
                    else -> "Slow, Wi-Fi/data badlo"
                }
                "Ping: $avg ms ($quality)"
            }
            runOnUiThread { pingView.text = msg }
        }
    }
}
